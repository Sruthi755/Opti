
import React from 'react';
import { SecurityVulnerability } from '../types';

interface SecurityReportProps {
  vulnerabilities: SecurityVulnerability[];
}

const SecurityReport: React.FC<SecurityReportProps> = ({ vulnerabilities }) => {
  const getSeverityStyles = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500/10 text-red-500 border-red-500/20';
      case 'high': return 'bg-orange-500/10 text-orange-500 border-orange-500/20';
      case 'medium': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
      default: return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
    }
  };

  if (vulnerabilities.length === 0) {
    return (
      <div className="bg-emerald-900/10 border border-emerald-500/20 rounded-xl p-6 text-center">
        <i className="fa-solid fa-shield-halved text-emerald-400 text-3xl mb-3"></i>
        <h3 className="text-emerald-400 font-bold">Secure Environment</h3>
        <p className="text-slate-400 text-sm mt-1">No major vulnerabilities detected in the refined code base.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {vulnerabilities.map((vuln, i) => (
        <div key={i} className={`border rounded-xl p-4 ${getSeverityStyles(vuln.severity)}`}>
          <div className="flex justify-between items-start mb-2">
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-bold tracking-widest">{vuln.severity}</span>
              <h4 className="font-bold text-lg">{vuln.title}</h4>
            </div>
            <i className="fa-solid fa-triangle-exclamation"></i>
          </div>
          <p className="text-slate-300 text-sm mb-3">{vuln.description}</p>
          <div className="bg-black/20 rounded p-3 text-xs">
            <span className="font-bold block mb-1">REMEDIATION APPLIED:</span>
            {vuln.remediation}
          </div>
        </div>
      ))}
    </div>
  );
};

export default SecurityReport;
