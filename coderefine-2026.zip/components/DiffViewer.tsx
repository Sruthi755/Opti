
import React from 'react';

interface DiffViewerProps {
  oldCode: string;
  newCode: string;
}

const DiffViewer: React.FC<DiffViewerProps> = ({ oldCode, newCode }) => {
  // Simple line-by-line diff for visualization
  const oldLines = oldCode.split('\n');
  const newLines = newCode.split('\n');
  
  const maxLength = Math.max(oldLines.length, newLines.length);

  return (
    <div className="grid grid-cols-2 gap-4 h-full bg-[#0f172a] rounded-lg overflow-hidden border border-slate-800">
      <div className="flex flex-col h-full border-r border-slate-800">
        <div className="px-4 py-2 bg-red-900/20 text-red-400 text-xs font-bold border-b border-slate-800">ORIGINAL</div>
        <div className="p-4 overflow-auto mono text-sm flex-1">
          {oldLines.map((line, i) => (
            <div key={i} className="whitespace-pre min-h-[1.5em] hover:bg-slate-800/30 px-1">
               <span className="text-slate-600 mr-4 select-none inline-block w-8 text-right">{i + 1}</span>
               <span className="text-slate-300">{line}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="flex flex-col h-full">
        <div className="px-4 py-2 bg-emerald-900/20 text-emerald-400 text-xs font-bold border-b border-slate-800">REFINED</div>
        <div className="p-4 overflow-auto mono text-sm flex-1">
          {newLines.map((line, i) => (
            <div key={i} className="whitespace-pre min-h-[1.5em] hover:bg-slate-800/30 px-1">
              <span className="text-slate-600 mr-4 select-none inline-block w-8 text-right">{i + 1}</span>
              <span className="text-emerald-400">{line}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DiffViewer;
