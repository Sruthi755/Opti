
import React from 'react';

interface CodeEditorProps {
  code: string;
  onChange: (code: string) => void;
  readOnly?: boolean;
  label?: string;
}

const CodeEditor: React.FC<CodeEditorProps> = ({ code, onChange, readOnly = false, label }) => {
  return (
    <div className="flex flex-col h-full bg-[#1e293b] rounded-lg border border-slate-700 overflow-hidden">
      {label && (
        <div className="px-4 py-2 bg-slate-800 border-b border-slate-700 text-xs font-semibold text-slate-400 uppercase tracking-wider flex justify-between items-center">
          {label}
          {readOnly && <span className="bg-slate-700 px-2 py-0.5 rounded text-[10px]">READ ONLY</span>}
        </div>
      )}
      <textarea
        value={code}
        onChange={(e) => onChange(e.target.value)}
        readOnly={readOnly}
        spellCheck={false}
        className="w-full h-full p-4 mono text-sm bg-transparent outline-none resize-none text-emerald-400 leading-relaxed"
        placeholder="// Paste your code here..."
      />
    </div>
  );
};

export default CodeEditor;
