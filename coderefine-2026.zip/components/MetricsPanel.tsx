
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface MetricsPanelProps {
  metrics: {
    complexityBefore: number;
    complexityAfter: number;
    linesRemoved: number;
    securityScore: number;
  };
}

const MetricsPanel: React.FC<MetricsPanelProps> = ({ metrics }) => {
  const complexityData = [
    { name: 'Original', value: metrics.complexityBefore },
    { name: 'Refined', value: metrics.complexityAfter },
  ];

  const reductionPercent = Math.round(((metrics.complexityBefore - metrics.complexityAfter) / metrics.complexityBefore) * 100);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
        <h4 className="text-slate-400 text-xs font-semibold uppercase mb-4">Structural Complexity</h4>
        <div className="h-40 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={complexityData}>
              <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} />
              <YAxis stroke="#94a3b8" fontSize={10} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f1f5f9' }}
                itemStyle={{ color: '#10b981' }}
              />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {complexityData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={index === 0 ? '#475569' : '#10b981'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-2 text-center">
          <span className="text-emerald-400 font-bold">-{reductionPercent}%</span>
          <span className="text-slate-500 text-xs ml-2">Complexity Reduction</span>
        </div>
      </div>

      <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 flex flex-col justify-center items-center">
        <h4 className="text-slate-400 text-xs font-semibold uppercase mb-2">Security Integrity</h4>
        <div className="relative w-24 h-24 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90">
            <circle cx="48" cy="48" r="40" stroke="#334155" strokeWidth="8" fill="transparent" />
            <circle 
              cx="48" cy="48" r="40" stroke="#10b981" strokeWidth="8" fill="transparent" 
              strokeDasharray={251.2} 
              strokeDashoffset={251.2 * (1 - metrics.securityScore / 100)} 
              strokeLinecap="round"
            />
          </svg>
          <span className="absolute text-xl font-bold text-white">{metrics.securityScore}%</span>
        </div>
        <span className="text-slate-400 text-xs mt-2">OWASP Compliance Score</span>
      </div>

      <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 flex flex-col justify-between">
        <div>
          <h4 className="text-slate-400 text-xs font-semibold uppercase mb-2">Code Cleanliness</h4>
          <div className="flex items-end gap-2">
            <span className="text-3xl font-bold text-emerald-400">{metrics.linesRemoved}</span>
            <span className="text-slate-500 text-sm mb-1">Unnecessary items purged</span>
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>Dead Code Removal</span>
            <span className="text-emerald-400">100%</span>
          </div>
          <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
            <div className="bg-emerald-500 h-full w-[100%]" />
          </div>
          <div className="flex justify-between text-[10px] text-slate-500">
             <span>Async Conversion</span>
            <span className="text-emerald-400">Active</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MetricsPanel;
