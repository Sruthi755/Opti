
import React, { useState, useCallback } from 'react';
import { RefinementState, RefinementResult } from './types';
import { INITIAL_CODE_SNIPPET } from './constants';
import { refineCode } from './services/geminiService';
import CodeEditor from './components/CodeEditor';
import DiffViewer from './components/DiffViewer';
import MetricsPanel from './components/MetricsPanel';
import SecurityReport from './components/SecurityReport';

const App: React.FC = () => {
  const [code, setCode] = useState(INITIAL_CODE_SNIPPET);
  const [state, setState] = useState<RefinementState>(RefinementState.IDLE);
  const [result, setResult] = useState<RefinementResult | null>(null);
  const [activeTab, setActiveTab] = useState<'diff' | 'report' | 'docs'>('diff');

  const handleRefine = async () => {
    setState(RefinementState.ANALYZING);
    try {
      // Simulate steps for DX "Trust" feel
      setTimeout(() => setState(RefinementState.REFACTORING), 1500);
      setTimeout(() => setState(RefinementState.SCANNING), 3000);
      
      const refined = await refineCode(code);
      setResult(refined);
      setState(RefinementState.COMPLETED);
    } catch (err) {
      console.error(err);
      setState(RefinementState.ERROR);
    }
  };

  const reset = () => {
    setState(RefinementState.IDLE);
    setResult(null);
    setActiveTab('diff');
  };

  const renderContent = () => {
    if (state === RefinementState.IDLE || state === RefinementState.ERROR) {
      return (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[70vh]">
          <div className="lg:col-span-8 flex flex-col">
            <CodeEditor 
              code={code} 
              onChange={setCode} 
              label="Source Code (JavaScript / TypeScript)"
            />
          </div>
          <div className="lg:col-span-4 flex flex-col justify-center gap-6 p-6 bg-slate-800/50 rounded-2xl border border-slate-700">
            <div className="text-center">
              <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/20">
                <i className="fa-solid fa-microchip text-emerald-500 text-2xl"></i>
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">CodeRefine Agent</h2>
              <p className="text-slate-400 text-sm leading-relaxed">
                Modern incremental cleanup partner. We optimize your AST, squash vulnerabilities, and generate enterprise documentation in seconds.
              </p>
            </div>
            
            <ul className="space-y-3 text-sm text-slate-300">
              <li className="flex items-center gap-3">
                <i className="fa-solid fa-check text-emerald-500 text-xs"></i>
                Structural AST Refactoring
              </li>
              <li className="flex items-center gap-3">
                <i className="fa-solid fa-check text-emerald-500 text-xs"></i>
                Vulnerability Elimination
              </li>
              <li className="flex items-center gap-3">
                <i className="fa-solid fa-check text-emerald-500 text-xs"></i>
                Dead Code Purging
              </li>
              <li className="flex items-center gap-3">
                <i className="fa-solid fa-check text-emerald-500 text-xs"></i>
                Auto-Docstring Injections
              </li>
            </ul>

            <button
              onClick={handleRefine}
              disabled={state === RefinementState.ANALYZING}
              className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 text-white rounded-xl font-bold shadow-lg shadow-emerald-900/20 transition-all flex items-center justify-center gap-3"
            >
              <i className="fa-solid fa-bolt-lightning"></i>
              REFINE CODEBASE
            </button>
            
            {state === RefinementState.ERROR && (
              <p className="text-red-400 text-xs text-center font-medium">
                Analysis failed. Please check your API key or code syntax.
              </p>
            )}
          </div>
        </div>
      );
    }

    if (state !== RefinementState.COMPLETED) {
      return (
        <div className="flex flex-col items-center justify-center h-[60vh] text-center">
          <div className="relative w-24 h-24 mb-8">
            <div className="absolute inset-0 border-4 border-slate-800 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-emerald-500 rounded-full border-t-transparent animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <i className="fa-solid fa-brain text-emerald-500 text-2xl"></i>
            </div>
          </div>
          <h2 className="text-2xl font-bold text-white mb-2 uppercase tracking-widest">{state}...</h2>
          <p className="text-slate-400 max-w-md">
            Our neural model is dissecting your logic, removing technical debt, and securing your endpoints.
          </p>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        {/* Metrics Overview */}
        {result && <MetricsPanel metrics={result.metrics} />}

        {/* Action Tabs */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex gap-4">
            <button 
              onClick={() => setActiveTab('diff')}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === 'diff' ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30' : 'text-slate-500 hover:text-slate-300'}`}
            >
              <i className="fa-solid fa-code-compare mr-2"></i> Side-by-Side Diff
            </button>
            <button 
              onClick={() => setActiveTab('report')}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === 'report' ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30' : 'text-slate-500 hover:text-slate-300'}`}
            >
              <i className="fa-solid fa-shield-virus mr-2"></i> Surgical Scan
            </button>
            <button 
              onClick={() => setActiveTab('docs')}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === 'docs' ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30' : 'text-slate-500 hover:text-slate-300'}`}
            >
              <i className="fa-solid fa-book mr-2"></i> Documentation
            </button>
          </div>
          <div className="flex gap-2">
            <button 
               onClick={reset}
               className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-semibold transition-all"
            >
              New Project
            </button>
            <button 
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-sm font-semibold transition-all flex items-center gap-2"
              onClick={() => alert('Refinement applied to context!')}
            >
              <i className="fa-solid fa-check"></i> Apply & Commit
            </button>
          </div>
        </div>

        {/* View Areas */}
        <div className="h-[60vh]">
          {activeTab === 'diff' && result && (
            <DiffViewer oldCode={code} newCode={result.refinedCode} />
          )}
          {activeTab === 'report' && result && (
            <div className="h-full overflow-auto pr-4">
               <SecurityReport vulnerabilities={result.securityReport} />
            </div>
          )}
          {activeTab === 'docs' && result && (
            <div className="h-full overflow-auto pr-4 bg-slate-900/50 rounded-xl p-8 border border-slate-800">
              <div className="prose prose-invert max-w-none">
                <h2 className="text-xl font-bold text-white mb-4">Architecture Summary</h2>
                <div className="bg-slate-800 p-6 rounded-xl text-slate-300 whitespace-pre-wrap mono text-sm leading-relaxed mb-8 border border-slate-700">
                  {result.summary}
                </div>
                
                <h2 className="text-xl font-bold text-white mb-4">Auto-Generated Context (REFINEMENT.md)</h2>
                <div className="bg-slate-800 p-6 rounded-xl text-slate-300 whitespace-pre-wrap mono text-sm leading-relaxed border border-slate-700">
                  {result.documentation}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col p-4 md:p-8 max-w-7xl mx-auto">
      <header className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="bg-emerald-500 p-2 rounded-lg shadow-lg shadow-emerald-500/20">
             <i className="fa-solid fa-wand-magic-sparkles text-white text-xl"></i>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white">CodeRefine <span className="text-emerald-500">2026</span></h1>
            <p className="text-[10px] uppercase font-bold text-slate-500 tracking-widest">Autonomous Refinement Agent v4.2.0</p>
          </div>
        </div>
        
        <div className="hidden md:flex items-center gap-6">
          <div className="flex flex-col items-end">
             <span className="text-xs font-bold text-slate-300">NEURAL ENGINE ACTIVE</span>
             <span className="text-[10px] text-emerald-500">GEMINI-3-PRO-EXPERIMENTAL</span>
          </div>
          <div className="h-8 w-[1px] bg-slate-800"></div>
          <button className="text-slate-400 hover:text-white transition-colors">
            <i className="fa-solid fa-gear text-lg"></i>
          </button>
        </div>
      </header>

      <main className="flex-1">
        {renderContent()}
      </main>

      <footer className="mt-8 pt-6 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center text-slate-500 text-xs gap-4">
        <div className="flex items-center gap-6">
          <span>&copy; 2026 RefineLabs AI</span>
          <span className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
             All Systems Operational
          </span>
        </div>
        <div className="flex items-center gap-4">
          <a href="#" className="hover:text-emerald-400 transition-colors">Documentation</a>
          <a href="#" className="hover:text-emerald-400 transition-colors">Privacy</a>
          <a href="#" className="hover:text-emerald-400 transition-colors">API Docs</a>
        </div>
      </footer>
    </div>
  );
};

export default App;
