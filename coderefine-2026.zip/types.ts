
export interface RefinementResult {
  refinedCode: string;
  summary: string;
  securityReport: SecurityVulnerability[];
  metrics: {
    complexityBefore: number;
    complexityAfter: number;
    linesRemoved: number;
    securityScore: number; // 0 to 100
  };
  documentation: string; // Markdown
}

export interface SecurityVulnerability {
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  remediation: string;
  line?: number;
}

export enum RefinementState {
  IDLE = 'IDLE',
  ANALYZING = 'ANALYZING',
  REFACTORING = 'REFACTORING',
  SCANNING = 'SCANNING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}

export interface DiffPart {
  type: 'added' | 'removed' | 'neutral';
  value: string;
}
