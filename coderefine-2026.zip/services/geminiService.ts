
import { GoogleGenAI, Type } from "@google/genai";
import { RefinementResult } from "../types";
import { SYSTEM_PROMPT } from "../constants";

export const refineCode = async (code: string): Promise<RefinementResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Please refine the following code:\n\n${code}`,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            refinedCode: { type: Type.STRING },
            summary: { type: Type.STRING },
            securityReport: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  severity: { type: Type.STRING },
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  remediation: { type: Type.STRING }
                },
                required: ["severity", "title", "description", "remediation"]
              }
            },
            metrics: {
              type: Type.OBJECT,
              properties: {
                complexityBefore: { type: Type.NUMBER },
                complexityAfter: { type: Type.NUMBER },
                linesRemoved: { type: Type.NUMBER },
                securityScore: { type: Type.NUMBER }
              },
              required: ["complexityBefore", "complexityAfter", "linesRemoved", "securityScore"]
            },
            documentation: { type: Type.STRING }
          },
          required: ["refinedCode", "summary", "securityReport", "metrics", "documentation"]
        }
      },
    });

    const resultText = response.text;
    if (!resultText) throw new Error("Empty response from AI");
    
    return JSON.parse(resultText) as RefinementResult;
  } catch (error) {
    console.error("Gemini Refinement Error:", error);
    throw error;
  }
};
